(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_370ce6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_370ce6._.js",
  "chunks": [
    "static/chunks/src_26aade._.js",
    "static/chunks/node_modules_date-fns_9a5017._.js",
    "static/chunks/node_modules_pako_dist_pako_esm_mjs_b4dc27._.js",
    "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cd.js",
    "static/chunks/node_modules_b240c5._.js",
    "static/chunks/src_lib_utils_e9de54._.js"
  ],
  "source": "dynamic"
});
